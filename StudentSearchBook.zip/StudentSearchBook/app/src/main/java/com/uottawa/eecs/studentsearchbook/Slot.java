package com.uottawa.eecs.studentsearchbook;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.PropertyName;





    public class Slot {
        private String tutorId;
        private String courseCode;
        private Timestamp startTime;
        private Timestamp endTime;
        private boolean isBooked;
        private String tutorName;
        private double tutorAvgRating;
        private String documentId;

        // Required empty constructor for Firestore deserialization
        public Slot() {}

        // Getters and Setters with Firestore property mapping
        @PropertyName("tutorId")
        public String getTutorId() {
            return tutorId;
        }

        @PropertyName("tutorId")
        public void setTutorId(String tutorId) {
            this.tutorId = tutorId;
        }

        @PropertyName("courseCode")
        public String getCourseCode() {
            return courseCode;
        }

        @PropertyName("courseCode")
        public void setCourseCode(String courseCode) {
            this.courseCode = courseCode;
        }

        @PropertyName("startTime")
        public Timestamp getStartTime() {
            return startTime;
        }

        @PropertyName("startTime")
        public void setStartTime(Timestamp startTime) {
            this.startTime = startTime;
        }

        @PropertyName("endTime")
        public Timestamp getEndTime() {
            return endTime;
        }

        @PropertyName("endTime")
        public void setEndTime(Timestamp endTime) {
            this.endTime = endTime;
        }

        @PropertyName("isBooked")
        public boolean isBooked() {
            return isBooked;
        }

        @PropertyName("isBooked")
        public void setBooked(boolean booked) {
            isBooked = booked;
        }

        @PropertyName("tutorName")
        public String getTutorName() {
            return tutorName;
        }

        @PropertyName("tutorName")
        public void setTutorName(String tutorName) {
            this.tutorName = tutorName;
        }

        @PropertyName("tutorAvgRating")
        public double getTutorAvgRating() {
            return tutorAvgRating;
        }

        @PropertyName("tutorAvgRating")
        public void setTutorAvgRating(double tutorAvgRating) {
            this.tutorAvgRating = tutorAvgRating;
        }


        public void setDocumentId(String documentId) {
            this.documentId = documentId;
        }


        public String getDocumentId() {
            return documentId;
        }
    }