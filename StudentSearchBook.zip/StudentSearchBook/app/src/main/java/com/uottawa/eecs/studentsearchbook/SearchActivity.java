package com.uottawa.eecs.studentsearchbook;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.uottawa.eecs.studentsearchbook.Slot;
import com.uottawa.eecs.studentsearchbook.SlotAdapter; 

public class SearchActivity extends AppCompatActivity {
    private EditText etCourseCode;
    private Button btnSearch;
    private ListView lvSlotResults;
    private TextView tvEmptyResult;

    private FirebaseFirestore db;
    private List<Slot> slotList;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        etCourseCode = findViewById(R.id.et_course_code);
        btnSearch = findViewById(R.id.btn_search);
        lvSlotResults = findViewById(R.id.lv_slot_results);
        tvEmptyResult = findViewById(R.id.tv_empty_result);

        db = FirebaseFirestore.getInstance();
        slotList = new ArrayList<>();
        mAuth = FirebaseAuth.getInstance();

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String courseCode = etCourseCode.getText().toString().trim().toUpperCase();
                if (courseCode.isEmpty()) {
                    etCourseCode.setError("Please enter course code");
                    return;
                }
                queryAvailableSlotsByCourse(courseCode);
            }
        });
    }

    private void queryAvailableSlotsByCourse(String courseCode) {
        slotList.clear();

        db.collection("slots")
                .whereEqualTo("courseCode", courseCode)
                .whereEqualTo("isBooked", false)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        Slot slot = document.toObject(Slot.class);
                        if (slot != null) {
                            slot.setDocumentId(document.getId());
                            slotList.add(slot);
                        }
                    }

                    if (slotList.isEmpty()) {
                        showEmptyResult();
                    } else {
                        showSlotResults();
                        SlotAdapter adapter = new SlotAdapter(SearchActivity.this, slotList);
                        lvSlotResults.setAdapter(adapter);
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(SearchActivity.this,
                            "Search failed: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void showEmptyResult() {
        lvSlotResults.setVisibility(View.GONE);
        tvEmptyResult.setVisibility(View.VISIBLE);
    }

    private void showSlotResults() {
        lvSlotResults.setVisibility(View.VISIBLE);
        tvEmptyResult.setVisibility(View.GONE);
    }

    public void showBookConfirmDialog(Slot selectedSlot) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Booking");

        String slotDetails = "Course Code: " + (selectedSlot.getCourseCode() != null ? selectedSlot.getCourseCode() : "Unknown") + "\n"
                + "Tutor: " + (selectedSlot.getTutorName() != null ? selectedSlot.getTutorName() : "Unknown Tutor") + "\n"
                + "Time: " + formatDateTime(selectedSlot.getStartTime()) + " - "
                + formatDateTime(selectedSlot.getEndTime());
        builder.setMessage(slotDetails);

        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                String studentId = getCurrentStudentId();
                if (studentId == null) {
                    Toast.makeText(SearchActivity.this,
                            "Please log in first",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                checkBookingConflict(studentId, selectedSlot);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.setCancelable(false);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private String getCurrentStudentId() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        return currentUser != null ? currentUser.getUid() : null;
    }

    private void checkBookingConflict(String studentId, Slot newSlot) {
        db.collection("bookings")
                .whereEqualTo("studentId", studentId)
                .whereEqualTo("isCancelled", false)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    boolean hasConflict = false;
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Timestamp existingStart = doc.getTimestamp("startTime");
                        Timestamp existingEnd = doc.getTimestamp("endTime");

                        if (existingStart != null && existingEnd != null) {
                            if (isTimeOverlapping(newSlot.getStartTime(), newSlot.getEndTime(), existingStart, existingEnd)) {
                                hasConflict = true;
                                break;
                            }
                        }
                    }

                    if (hasConflict) {
                        Toast.makeText(SearchActivity.this,
                                "Conflict! You already have a booking at this time",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        createBookingRecord(studentId, newSlot);
                        Toast.makeText(SearchActivity.this,
                                "No conflict. Proceeding to book...",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(SearchActivity.this,
                            "Failed to check conflict: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private boolean isTimeOverlapping(Timestamp newStart, Timestamp newEnd, Timestamp existingStart, Timestamp existingEnd) {
        return newStart.compareTo(existingEnd) < 0 && newEnd.compareTo(existingStart) > 0;
    }

    // Implemented: Create booking record + update slot status
    private void createBookingRecord(String studentId, Slot newSlot) {
        // 1. Create booking document in "bookings" collection
        Map<String, Object> booking = new HashMap<>();
        booking.put("studentId", studentId);
        booking.put("tutorId", newSlot.getTutorId());
        booking.put("courseCode", newSlot.getCourseCode());
        booking.put("startTime", newSlot.getStartTime());
        booking.put("endTime", newSlot.getEndTime());
        booking.put("isCancelled", false);
        booking.put("bookingTime", Timestamp.now()); // Record booking time

        db.collection("bookings")
                .add(booking)
                .addOnSuccessListener(documentReference -> {
                    // 2. Update slot's "isBooked" status to true (mark as booked)
                    db.collection("slots")
                            .document(newSlot.getDocumentId())
                            .update("isBooked", true)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(SearchActivity.this,
                                        "Booking successful!",
                                        Toast.LENGTH_SHORT).show();
                                // Refresh slot list to remove booked slot
                                String currentCourseCode = etCourseCode.getText().toString().trim().toUpperCase();
                                if (!currentCourseCode.isEmpty()) {
                                    queryAvailableSlotsByCourse(currentCourseCode);
                                }
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(SearchActivity.this,
                                        "Booking created but slot update failed: " + e.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(SearchActivity.this,
                            "Booking failed: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    public String formatDateTime(Timestamp timestamp) {
        if (timestamp == null) return "Invalid Time";
        java.util.Date date = timestamp.toDate();
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm");
            return sdf.format(date);
        } catch (Exception e) {
            return "Invalid Time";
        }
    }
}