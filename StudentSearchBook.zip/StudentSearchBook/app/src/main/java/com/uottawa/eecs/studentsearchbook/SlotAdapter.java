package com.uottawa.eecs.studentsearchbook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.uottawa.eecs.model.Slot; // 替换为你的 Slot 类实际包名
import com.uottawa.eecs.SearchActivity; // 替换为你的 SearchActivity 实际包名
import java.util.List;

public class SlotAdapter extends ArrayAdapter<Slot> {
    private Context mContext;
    private List<Slot> mSlotList;
    private LayoutInflater mInflater;

    // constructor
    public SlotAdapter(Context context, List<Slot> slotList) {
        super(context, 0, slotList);
        this.mContext = context;
        this.mSlotList = slotList;
        this.mInflater = LayoutInflater.from(context);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if (convertView == null) {
            // load item_slot.xml UI screen
            convertView = mInflater.inflate(R.layout.item_slot, parent, false);

            // initialize ViewHolder
            holder = new ViewHolder();
            holder.tvTutorName = convertView.findViewById(R.id.tv_tutor_name);
            holder.tvTutorRating = convertView.findViewById(R.id.tv_tutor_rating);
            holder.tvSlotDatetime = convertView.findViewById(R.id.tv_slot_datetime);
            holder.btnBookSlot = convertView.findViewById(R.id.btn_book_slot);


            convertView.setTag(holder);
        } else {

            holder = (ViewHolder) convertView.getTag();
        }

        // get current slot data
        Slot currentSlot = mSlotList.get(position);
        if (currentSlot == null) {
            return convertView;
        }


        // get professor's name
        if (currentSlot.getTutorName() != null) {
            holder.tvTutorName.setText(currentSlot.getTutorName());
        } else {
            holder.tvTutorName.setText("Unknown Tutor");
        }

        // get professor's rating
        double avgRating = currentSlot.getTutorAvgRating(); // 假设 Slot 有此 getter
        holder.tvTutorRating.setText(String.format("%.1f", avgRating));


        // get date of slot time
        if (mContext instanceof SearchActivity) {
            SearchActivity activity = (SearchActivity) mContext;
            String startTimeStr = activity.formatDateTime(currentSlot.getStartTime());
            String endTimeStr = activity.formatDateTime(currentSlot.getEndTime());
            holder.tvSlotDatetime.setText(startTimeStr + " - " + endTimeStr);
        }

        holder.btnBookSlot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mContext instanceof SearchActivity) {
                    ((SearchActivity) mContext).showBookConfirmDialog(currentSlot);
                }
            }
        });

        return convertView;
    }


    private static class ViewHolder {
        TextView tvTutorName;
        TextView tvTutorRating;
        TextView tvStarIcon;
        TextView tvSlotDatetime;
        Button btnBookSlot;
    }
}
