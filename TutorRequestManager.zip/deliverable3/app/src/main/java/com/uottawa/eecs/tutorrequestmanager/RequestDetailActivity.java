package com.uottawa.eecs.tutorrequestmanager;

//UI display and approve/reject operation

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.firestore.FirebaseFirestore;
import com.uottawa.eecs.tutorrequestmanager.model.SessionRequest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.HashMap;
import java.util.Map;

public class RequestDetailActivity extends AppCompatActivity {

    private TextView tvDetailCourse, tvDetailTime, tvDetailStudentName, tvDetailStudentEmail, tvDetailStudentPhone;
    private Button btnApprove, btnReject;
    private SessionRequest mRequest;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private SimpleDateFormat mTimeFormat = new SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_detail);

        mRequest = getIntent().getParcelableExtra("REQUEST_DATA");

        if (mRequest == null) {
            finish();
            return;
        }

        initViews();
        populateData();
        setupClickListeners();
    }

    private void initViews() {
        tvDetailCourse = findViewById(R.id.tv_detail_course);
        tvDetailTime = findViewById(R.id.tv_detail_time);
        tvDetailStudentName = findViewById(R.id.tv_detail_student_name);
        tvDetailStudentEmail = findViewById(R.id.tv_detail_student_email);
        tvDetailStudentPhone = findViewById(R.id.tv_detail_student_phone);
        btnApprove = findViewById(R.id.btn_approve);
        btnReject = findViewById(R.id.btn_reject);
    }

    private void populateData() {
        tvDetailCourse.setText("Course: " + mRequest.getCourse());

        String time = mTimeFormat.format(new Date(mRequest.getStartTime()))
                + " - " + mTimeFormat.format(new Date(mRequest.getEndTime()));
        tvDetailTime.setText("Time: " + time);

        tvDetailStudentName.setText("Name: " + mRequest.getStudentName());
        tvDetailStudentEmail.setText("Email: " + mRequest.getStudentEmail());
        tvDetailStudentPhone.setText("Phone: " + mRequest.getStudentPhone());
    }

    private void setupClickListeners() {
        btnApprove.setOnClickListener(v -> handleApprove());
        btnReject.setOnClickListener(v -> handleReject());
    }

    private void handleApprove() {
        if (mRequest.getId() == null) return;

        db.collection("sessionRequests").document(mRequest.getId())
                .update("status", "approved")
                .addOnSuccessListener(aVoid -> {
                    createSession();
                    updateSlotStatus(true);
                    Toast.makeText(this, "Request approved", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Approval failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void handleReject() {
        if (mRequest.getId() == null) return;

        db.collection("sessionRequests").document(mRequest.getId())
                .update("status", "rejected")
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Request rejected", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Rejection failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void createSession() {
        Map<String, Object> session = new HashMap<>();
        session.put("requestId", mRequest.getId());
        session.put("studentUid", mRequest.getStudentUid());
        session.put("tutorUid", mRequest.getTutorUid());
        session.put("course", mRequest.getCourse());
        session.put("startTime", mRequest.getStartTime());
        session.put("endTime", mRequest.getEndTime());
        session.put("status", "upcoming");
        session.put("createdAt", new Date().getTime());

        db.collection("sessions").add(session);
    }

    private void updateSlotStatus(boolean isBooked) {
        db.collection("availabilitySlots")
                .whereEqualTo("tutorUid", mRequest.getTutorUid())
                .whereEqualTo("startTime", mRequest.getStartTime())
                .whereEqualTo("endTime", mRequest.getEndTime())
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    for (int i = 0; i < queryDocumentSnapshots.size(); i++) {
                        queryDocumentSnapshots.getDocuments().get(i)
                                .getReference()
                                .update("booked", isBooked);
                    }
                });
    }
}