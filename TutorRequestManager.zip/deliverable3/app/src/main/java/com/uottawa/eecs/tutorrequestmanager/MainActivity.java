package com.uottawa.eecs.tutorrequestmanager;



import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.uottawa.eecs.tutorrequestmanager.adapter.PendingRequestsAdapter;
import com.uottawa.eecs.tutorrequestmanager.model.SessionRequest;
import com.uottawa.eecs.tutorrequestmanager.model.User;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity implements PendingRequestsAdapter.OnItemClickListener {

    private RecyclerView rvPendingRequests;
    private EditText etSearch;
    private TextView tvEmpty, tvLoading;
    private PendingRequestsAdapter mAdapter;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private String currentTutorUid;
    private List<SessionRequest> mAllRequests = new ArrayList<>();
    private List<SessionRequest> mFilteredRequests = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupRecyclerView();
        setupSearchFilter();
    }

    @Override
    protected void onStart() {
        super.onStart();
        checkUserAuthentication();
    }

    private void initViews() {
        rvPendingRequests = findViewById(R.id.rv_pending_requests);
        etSearch = findViewById(R.id.et_search);
        tvEmpty = findViewById(R.id.tv_empty);
        tvLoading = findViewById(R.id.tv_loading);
    }

    private void setupRecyclerView() {
        rvPendingRequests.setLayoutManager(new LinearLayoutManager(this));
        mAdapter = new PendingRequestsAdapter(mFilteredRequests, this);
        rvPendingRequests.setAdapter(mAdapter);
    }

    private void setupSearchFilter() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                filterRequests(s.toString().trim().toLowerCase());
            }
        });
    }

    private void checkUserAuthentication() {
        FirebaseUser firebaseUser = mAuth.getCurrentUser();
        if (firebaseUser == null) {
            Toast.makeText(this, "Please log in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadUserProfile(firebaseUser.getUid());
    }

    private void loadUserProfile(String uid) {
        db.collection("users").document(uid)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    User user = documentSnapshot.toObject(User.class);
                    if (user != null && "TUTOR".equals(user.getRole())) {
                        currentTutorUid = uid;
                        loadPendingRequests();
                    } else {
                        Toast.makeText(this, "Not authorized as Tutor", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load profile: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    private void loadPendingRequests() {
        showLoading();

        db.collection("sessionRequests")
                .whereEqualTo("status", "PENDING")
                .whereEqualTo("tutorUid", currentTutorUid)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    mAllRequests.clear();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        SessionRequest request = document.toObject(SessionRequest.class);
                        request.setId(document.getId());
                        mAllRequests.add(request);
                    }
                    mFilteredRequests.clear();
                    mFilteredRequests.addAll(mAllRequests);
                    mAdapter.updateData(mFilteredRequests);
                    checkEmptyState();
                    hideLoading();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load requests: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    hideLoading();
                    checkEmptyState();
                });
    }

    private void filterRequests(String keyword) {
        if (keyword.isEmpty()) {
            mFilteredRequests.clear();
            mFilteredRequests.addAll(mAllRequests);
        } else {
            mFilteredRequests.clear();
            mFilteredRequests.addAll(
                    mAllRequests.stream()
                            .filter(request -> request.getCourse().toLowerCase().contains(keyword)
                                    || request.getStudentName().toLowerCase().contains(keyword))
                            .collect(Collectors.toList())
            );
        }
        mAdapter.updateData(mFilteredRequests);
        checkEmptyState();
    }

    private void showLoading() {
        tvLoading.setVisibility(TextView.VISIBLE);
        tvEmpty.setVisibility(TextView.GONE);
        rvPendingRequests.setVisibility(RecyclerView.GONE);
    }

    private void hideLoading() {
        tvLoading.setVisibility(TextView.GONE);
    }

    private void checkEmptyState() {
        if (mFilteredRequests.isEmpty()) {
            tvEmpty.setVisibility(TextView.VISIBLE);
            rvPendingRequests.setVisibility(RecyclerView.GONE);
        } else {
            tvEmpty.setVisibility(TextView.GONE);
            rvPendingRequests.setVisibility(RecyclerView.VISIBLE);
        }
    }

    @Override
    public void onItemClick(SessionRequest request) {
        Intent intent = new Intent(this, RequestDetailActivity.class);
        intent.putExtra("REQUEST_DATA", request);
        startActivity(intent);
    }
}