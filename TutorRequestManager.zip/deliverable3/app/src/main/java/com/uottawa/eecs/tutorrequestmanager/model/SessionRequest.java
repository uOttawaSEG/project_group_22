package com.uottawa.eecs.tutorrequestmanager.model;

import android.os.Parcel;
import android.os.Parcelable;

public class SessionRequest implements Parcelable {
    private String id; // request the ID from firebase
    private String course; // course code
    private long requestTime;
    private String studentUid;
    private String studentName;
    private String studentEmail;
    private String studentPhone;
    private String status; // status of requests
    private long startTime;
    private long endTime;
    private String tutorUid;

    public SessionRequest() {}

    protected SessionRequest(Parcel in) {
        id = in.readString();
        course = in.readString();
        requestTime = in.readLong();
        studentUid = in.readString();
        studentName = in.readString();
        studentEmail = in.readString();
        studentPhone = in.readString();
        status = in.readString();
        startTime = in.readLong();
        endTime = in.readLong();
        tutorUid = in.readString();
    }

    public static final Creator<SessionRequest> CREATOR = new Creator<SessionRequest>() {
        @Override
        public SessionRequest createFromParcel(Parcel in) {
            return new SessionRequest(in);
        }

        @Override
        public SessionRequest[] newArray(int size) {
            return new SessionRequest[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(course);
        dest.writeLong(requestTime);
        dest.writeString(studentUid);
        dest.writeString(studentName);
        dest.writeString(studentEmail);
        dest.writeString(studentPhone);
        dest.writeString(status);
        dest.writeLong(startTime);
        dest.writeLong(endTime);
        dest.writeString(tutorUid);
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }
    public long getRequestTime() { return requestTime; }
    public void setRequestTime(long requestTime) { this.requestTime = requestTime; }
    public String getStudentUid() { return studentUid; }
    public void setStudentUid(String studentUid) { this.studentUid = studentUid; }
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public String getStudentEmail() { return studentEmail; }
    public void setStudentEmail(String studentEmail) { this.studentEmail = studentEmail; }
    public String getStudentPhone() { return studentPhone; }
    public void setStudentPhone(String studentPhone) { this.studentPhone = studentPhone; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public long getStartTime() { return startTime; }
    public void setStartTime(long startTime) { this.startTime = startTime; }
    public long getEndTime() { return endTime; }
    public void setEndTime(long endTime) { this.endTime = endTime; }
    public String getTutorUid() { return tutorUid; }
    public void setTutorUid(String tutorUid) { this.tutorUid = tutorUid; }
}
