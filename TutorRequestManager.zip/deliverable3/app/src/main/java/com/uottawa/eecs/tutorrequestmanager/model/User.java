package com.uottawa.eecs.tutorrequestmanager.model;

public class User {
    private String uid;
    private String role; // User's role ("Tutor" or "Student")
    private String firstName;
    private String lastName;

    public User() {}

    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
}
