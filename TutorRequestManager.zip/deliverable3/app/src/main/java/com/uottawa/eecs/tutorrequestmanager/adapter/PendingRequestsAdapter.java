package com.uottawa.eecs.tutorrequestmanager.adapter;


//connecting SessionRequest and RecyclerView(list UI)
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.uottawa.eecs.tutorrequestmanager.R;
import com.uottawa.eecs.tutorrequestmanager.model.SessionRequest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PendingRequestsAdapter extends RecyclerView.Adapter<PendingRequestsAdapter.RequestViewHolder> {

    private List<SessionRequest> mRequests;
    private OnItemClickListener mListener;
    private SimpleDateFormat mTimeFormat = new SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US);

    public interface OnItemClickListener {
        void onItemClick(SessionRequest request);
    }

    public PendingRequestsAdapter(List<SessionRequest> requests, OnItemClickListener listener) {
        this.mRequests = requests;
        this.mListener = listener;
    }

    @NonNull
    @Override
    public RequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_request_list, parent, false);
        return new RequestViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RequestViewHolder holder, int position) {
        SessionRequest request = mRequests.get(position);

        holder.tvStudentName.setText(request.getStudentName());
        holder.tvCourse.setText("Course: " + request.getCourse());

        String timeSlot = "Time: " + mTimeFormat.format(new Date(request.getStartTime()))
                + " - " + mTimeFormat.format(new Date(request.getEndTime()));
        holder.tvTimeSlot.setText(timeSlot);

        holder.itemView.setOnClickListener(v -> {
            if (mListener != null) {
                mListener.onItemClick(request);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mRequests == null ? 0 : mRequests.size();
    }

    public void updateData(List<SessionRequest> newRequests) {
        this.mRequests.clear();
        this.mRequests.addAll(newRequests);
        notifyDataSetChanged();
    }

    public static class RequestViewHolder extends RecyclerView.ViewHolder {
        TextView tvStudentName, tvCourse, tvTimeSlot;

        public RequestViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStudentName = itemView.findViewById(R.id.tv_student_name);
            tvCourse = itemView.findViewById(R.id.tv_course);
            tvTimeSlot = itemView.findViewById(R.id.tv_time_slot);
        }
    }
}